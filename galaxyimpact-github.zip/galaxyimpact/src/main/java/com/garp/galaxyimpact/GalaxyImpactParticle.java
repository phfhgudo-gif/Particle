package com.garp.galaxyimpact;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.DefaultParticleType;

@Environment(EnvType.CLIENT)
public class GalaxyImpactParticle extends SpriteBillboardParticle {
	private final SpriteProvider spriteProvider;
	private final float spin;

	protected GalaxyImpactParticle(ClientWorld world, double x, double y, double z,
								   double vx, double vy, double vz, SpriteProvider spriteProvider) {
		super(world, x, y, z, vx, vy, vz);
		this.spriteProvider = spriteProvider;

		// ใช้ความเร็วที่ส่งมาตรง ๆ (ไม่เอาค่าสุ่มของคลาสแม่)
		this.velocityX = vx;
		this.velocityY = vy;
		this.velocityZ = vz;

		this.maxAge = 28 + this.random.nextInt(18);
		this.scale = 0.22F + this.random.nextFloat() * 0.18F;
		this.collidesWithWorld = false;
		this.spin = (this.random.nextFloat() - 0.5F) * 0.3F;
		this.angle = this.random.nextFloat() * (float) Math.PI * 2;
		this.prevAngle = this.angle;

		// โทนสีกาแล็กซี่: ม่วง-ฟ้า-ชมพู
		float t = this.random.nextFloat();
		if (t < 0.4F) {
			this.setColor(0.65F, 0.45F, 1.0F);
		} else if (t < 0.75F) {
			this.setColor(0.45F, 0.75F, 1.0F);
		} else {
			this.setColor(1.0F, 0.55F, 0.85F);
		}

		this.setSpriteForAge(spriteProvider);
	}

	@Override
	public void tick() {
		this.prevPosX = this.x;
		this.prevPosY = this.y;
		this.prevPosZ = this.z;

		if (this.age++ >= this.maxAge) {
			this.markDead();
			return;
		}

		this.move(this.velocityX, this.velocityY, this.velocityZ);
		this.velocityX *= 0.9;
		this.velocityY *= 0.9;
		this.velocityZ *= 0.9;

		this.prevAngle = this.angle;
		this.angle += this.spin;

		// เฟรมเปลี่ยนตามอายุ + ค่อย ๆ จางหาย + หดเล็กลง
		this.setSpriteForAge(this.spriteProvider);
		float life = (float) this.age / (float) this.maxAge;
		this.setAlpha(1.0F - life * life);
		this.scale *= 0.985F;
	}

	@Override
	public ParticleTextureSheet getType() {
		return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
	}

	// เรืองแสงเต็มที่ ไม่ขึ้นกับความมืดรอบตัว
	@Override
	public int getBrightness(float tint) {
		return 0xF000F0;
	}

	@Environment(EnvType.CLIENT)
	public static class Factory implements ParticleFactory<DefaultParticleType> {
		private final SpriteProvider spriteProvider;

		public Factory(SpriteProvider spriteProvider) {
			this.spriteProvider = spriteProvider;
		}

		@Override
		public Particle createParticle(DefaultParticleType type, ClientWorld world,
									   double x, double y, double z, double vx, double vy, double vz) {
			return new GalaxyImpactParticle(world, x, y, z, vx, vy, vz, this.spriteProvider);
		}
	}
}
