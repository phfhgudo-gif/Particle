package com.garp.galaxyimpact;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.client.particle.ParticleTextureSheet;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.particle.SpriteProvider;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.DefaultParticleType;

/**
 * ฮาคิราชันย์: สายฟ้าดำ-แดงที่แลบวูบวาบ เปลี่ยนรูปและมุมสุ่มทุกเสี้ยววินาที
 */
@Environment(EnvType.CLIENT)
public class HaoshokuHakiParticle extends SpriteBillboardParticle {
	private final SpriteProvider spriteProvider;
	private final float baseScale;

	protected HaoshokuHakiParticle(ClientWorld world, double x, double y, double z,
								   double vx, double vy, double vz, SpriteProvider spriteProvider) {
		super(world, x, y, z, vx, vy, vz);
		this.spriteProvider = spriteProvider;

		this.velocityX = vx;
		this.velocityY = vy;
		this.velocityZ = vz;

		this.maxAge = 6 + this.random.nextInt(8);
		this.baseScale = 0.35F + this.random.nextFloat() * 0.55F;
		this.scale = this.baseScale;
		this.collidesWithWorld = false;

		this.angle = this.random.nextFloat() * (float) (Math.PI * 2);
		this.prevAngle = this.angle;

		this.setSprite(spriteProvider.getSprite(this.random));
	}

	@Override
	public void tick() {
		this.prevPosX = this.x;
		this.prevPosY = this.y;
		this.prevPosZ = this.z;

		if (this.age++ >= this.maxAge) {
			this.markDead();
			return;
		}

		// สั่นกระตุกเหมือนไฟฟ้าช็อต
		this.move(this.velocityX + (this.random.nextFloat() - 0.5F) * 0.06,
				this.velocityY + (this.random.nextFloat() - 0.5F) * 0.06,
				this.velocityZ + (this.random.nextFloat() - 0.5F) * 0.06);
		this.velocityX *= 0.85;
		this.velocityY *= 0.85;
		this.velocityZ *= 0.85;

		// สลับรูป + หมุนมุมสุ่มแบบกระโดด (ไม่ interpolate) ให้ดูเป็นแสงแลบ
		if (this.random.nextInt(2) == 0) {
			this.setSprite(this.spriteProvider.getSprite(this.random));
			this.angle = this.random.nextFloat() * (float) (Math.PI * 2);
			this.prevAngle = this.angle;
		}

		// วูบวาบ แล้วจางหายช่วงท้าย
		float life = (float) this.age / (float) this.maxAge;
		float flicker = 0.55F + this.random.nextFloat() * 0.45F;
		this.setAlpha(flicker * (1.0F - life * life));
		this.scale = this.baseScale * (0.8F + this.random.nextFloat() * 0.4F);
	}

	@Override
	public ParticleTextureSheet getType() {
		return ParticleTextureSheet.PARTICLE_SHEET_TRANSLUCENT;
	}

	@Override
	public int getBrightness(float tint) {
		return 0xF000F0;
	}

	@Environment(EnvType.CLIENT)
	public static class Factory implements ParticleFactory<DefaultParticleType> {
		private final SpriteProvider spriteProvider;

		public Factory(SpriteProvider spriteProvider) {
			this.spriteProvider = spriteProvider;
		}

		@Override
		public Particle createParticle(DefaultParticleType type, ClientWorld world,
									   double x, double y, double z, double vx, double vy, double vz) {
			return new HaoshokuHakiParticle(world, x, y, z, vx, vy, vz, this.spriteProvider);
		}
	}
}
