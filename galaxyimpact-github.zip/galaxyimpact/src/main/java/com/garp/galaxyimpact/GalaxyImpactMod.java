package com.garp.galaxyimpact;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.particle.DefaultParticleType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class GalaxyImpactMod implements ModInitializer {
	public static final String MOD_ID = "galaxyimpact";

	// particle ชนิดใหม่: /particle galaxyimpact:galaxy_impact
	public static final DefaultParticleType GALAXY_IMPACT = FabricParticleTypes.simple();

	// เสียงใหม่: /playsound galaxyimpact:galaxy_impact master @a ~ ~ ~ 2 1
	public static final Identifier GALAXY_IMPACT_SOUND_ID = new Identifier(MOD_ID, "galaxy_impact");
	public static final SoundEvent GALAXY_IMPACT_SOUND = SoundEvent.of(GALAXY_IMPACT_SOUND_ID);

	// ฮาคิราชันย์: /particle galaxyimpact:haoshoku_haki
	public static final DefaultParticleType HAOSHOKU_HAKI = FabricParticleTypes.simple();

	// เสียง: /playsound galaxyimpact:haoshoku_haki master @a ~ ~ ~ 2 1
	public static final Identifier HAOSHOKU_HAKI_SOUND_ID = new Identifier(MOD_ID, "haoshoku_haki");
	public static final SoundEvent HAOSHOKU_HAKI_SOUND = SoundEvent.of(HAOSHOKU_HAKI_SOUND_ID);

	@Override
	public void onInitialize() {
		Registry.register(Registries.PARTICLE_TYPE, new Identifier(MOD_ID, "galaxy_impact"), GALAXY_IMPACT);
		Registry.register(Registries.SOUND_EVENT, GALAXY_IMPACT_SOUND_ID, GALAXY_IMPACT_SOUND);

		Registry.register(Registries.PARTICLE_TYPE, new Identifier(MOD_ID, "haoshoku_haki"), HAOSHOKU_HAKI);
		Registry.register(Registries.SOUND_EVENT, HAOSHOKU_HAKI_SOUND_ID, HAOSHOKU_HAKI_SOUND);
	}
}
