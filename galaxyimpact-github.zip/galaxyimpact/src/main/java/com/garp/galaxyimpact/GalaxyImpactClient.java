package com.garp.galaxyimpact;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;

@Environment(EnvType.CLIENT)
public class GalaxyImpactClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ParticleFactoryRegistry.getInstance().register(GalaxyImpactMod.GALAXY_IMPACT, GalaxyImpactParticle.Factory::new);
		ParticleFactoryRegistry.getInstance().register(GalaxyImpactMod.HAOSHOKU_HAKI, HaoshokuHakiParticle.Factory::new);
	}
}
