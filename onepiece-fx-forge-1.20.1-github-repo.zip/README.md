# One Piece FX (Forge 1.20.1)

Garp's **Galaxy Impact** and **Conqueror's (Haoshoku) Haki** as 3D particle effects + sound.

    /function opfx:galaxy_impact
    /function opfx:haki
    /function opfx:stop

## Get the jar
- GitHub: push to `main` -> Actions -> latest run -> Artifacts -> `OnePieceFX-jar`.
- Tag `v1.0.0` (`git tag v1.0.0 && git push --tags`) -> the jar is attached to a Release.
- Local: needs JDK 17 + Gradle 8.5 + Python 3, then `gradle build` -> `build/libs/`.

Put the jar in `mods/` (Forge 1.20.1, 47.x). Tune particle count with `DENSITY` in `tools/generate_datapack.py`.
