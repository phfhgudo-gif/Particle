#!/usr/bin/env python3
"""
One Piece FX datapack generator  (Minecraft Java 1.20.1, data pack format 15)
  - Garp's  Galaxy Impact
  - Conqueror's (Haoshoku) Haki
Usage:  python3 generate_datapack.py [output_dir] [--no-mcmeta]
If your PC lags, lower DENSITY (e.g. 0.6). Raise it (1.2) for a denser effect.
All shapes are drawn with local coordinates (^left ^up ^forward) around a marker
that is spawned at the caster, so the effect follows the direction you face.
"""
import math, random, os, shutil, sys

DENSITY = 0.8
SEED = 11
CF = 12.0                      # Galaxy Impact lands this many blocks in front of the caster
_args = [a for a in sys.argv[1:] if not a.startswith('--')]
OUT = _args[0] if _args else 'datapack'
NO_MCMETA = '--no-mcmeta' in sys.argv   # used when the files go inside a Forge mod jar
NS = 'opfx'
random.seed(SEED)

# ---------------------------------------------------------------- helpers
def N(x):
    return int(round(x * DENSITY))

def f2(v):
    s = '%.2f' % v
    if '.' in s:
        s = s.rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s

def loc(p):
    return '^%s ^%s ^%s' % (f2(p[0]), f2(p[1]), f2(p[2]))

def dl(d):
    return d if isinstance(d, tuple) else (d, d, d)

def dust(c, s, p, d=0.0, n=1):
    dx, dy, dz = dl(d)
    return 'particle minecraft:dust %s %s %s %s %s %s %s %s 0 %d force' % (
        f2(c[0]), f2(c[1]), f2(c[2]), f2(s), loc(p), f2(dx), f2(dy), f2(dz), n)

def dust_ct(c1, s, c2, p, d=0.0, n=1):
    dx, dy, dz = dl(d)
    return 'particle minecraft:dust_color_transition %s %s %s %s %s %s %s %s %s %s %s 0 %d force' % (
        f2(c1[0]), f2(c1[1]), f2(c1[2]), f2(s), f2(c2[0]), f2(c2[1]), f2(c2[2]),
        loc(p), f2(dx), f2(dy), f2(dz), n)

def part(name, p, d=0.0, speed=0.0, n=1):
    dx, dy, dz = dl(d)
    return 'particle minecraft:%s %s %s %s %s %s %d force' % (
        name, loc(p), f2(dx), f2(dy), f2(dz), f2(speed), n)

def add(a, b): return tuple(x + y for x, y in zip(a, b))
def mul(a, k): return tuple(x * k for x in a)
def lerp(a, b, t): return tuple(x + (y - x) * t for x, y in zip(a, b))
def dist(a, b): return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))
def norm(a):
    n = math.sqrt(sum(x * x for x in a)) or 1
    return mul(a, 1 / n)

def rnd_dir(ymin=-0.15):
    while True:
        v = (random.uniform(-1, 1), random.uniform(ymin, 1), random.uniform(-1, 1))
        n = math.sqrt(sum(x * x for x in v))
        if 0.1 < n <= 1:
            return mul(v, 1 / n)

def roty(p, a):
    c, s = math.cos(a), math.sin(a)
    return (p[0] * c - p[2] * s, p[1], p[0] * s + p[2] * c)

def fib(n, hemi=False):
    pts = []
    for i in range(n):
        y = (i + 0.5) / n if hemi else 1 - 2 * (i + 0.5) / n
        r = math.sqrt(max(0.0, 1 - y * y))
        th = i * 2.399963
        pts.append((r * math.cos(th), y, r * math.sin(th)))
    return pts

def W(p):                      # centre-relative -> caster-local
    return (p[0], p[1], p[2] + CF)

BLACK = (0, 0, 0)
RED = (0.85, 0.03, 0.06)
WHITE = (1, 1, 1)
GOLD = (1, 0.85, 0.55)
PURP = (0.7, 0.3, 0.95)
BLUE = (0.25, 0.45, 1)
PINK = (0.95, 0.35, 0.75)

def bolt(A, B, segs=5, jit=0.8, c1=BLACK, c2=RED, sz=None, spark=True):
    """Jagged black lightning with red edge, points already in caster-local coords."""
    L = dist(A, B)
    sp = max(1.1, L / 9)
    sz = sz or max(1.0, min(3.0, sp * 0.9))
    pts = [A]
    for i in range(1, segs):
        q = lerp(A, B, i / segs)
        pts.append(add(q, (random.uniform(-jit, jit), random.uniform(-jit, jit), random.uniform(-jit, jit))))
    pts.append(B)
    out = []
    c = 0
    for a, b in zip(pts, pts[1:]):
        k = max(1, int(dist(a, b) / sp))
        for j in range(k):
            p = lerp(a, b, (j + 0.5) / k)
            out.append(dust(c1, sz, p, 0.05))
            c += 1
            if c % 2 == 0:
                out.append(dust(c2, sz * 0.75, add(p, (random.uniform(-.3, .3), random.uniform(-.3, .3), random.uniform(-.3, .3))), 0.05))
            if spark and c % 3 == 0:
                out.append(part('electric_spark', p, 0.2, 0.02, 1))
    return out

FIB20 = fib(20)
FIB10 = fib(10)
HEMI90 = fib(90, True)
HEMI45 = fib(45, True)

# ---------------------------------------------------------------- GALAXY IMPACT
GI_T = 360
T_IMPACT = 210      # 10.5 s : strongest bass hit in the audio
T_AFTER = 300       # 15.0 s : second loud rise in the audio

def gi(t):
    L = []
    # ---- starfield (the sky turns into a galaxy)
    if t <= 335:
        k = 1.0
        if t < 40: k = t / 40
        if t > 300: k = (335 - t) / 35
        for _ in range(N(14 * k)):
            r = random.uniform(14, 34); th = random.uniform(0, 6.283); ph = random.uniform(0.05, 1.3)
            p = W((r * math.cos(ph) * math.cos(th), r * math.sin(ph), r * math.cos(ph) * math.sin(th)))
            if random.random() < 0.5:
                L.append(part('end_rod', p, 0.1, 0.0, 1))
            else:
                L.append(dust(random.choice([WHITE, (0.7, 0.8, 1), (0.9, 0.7, 1)]), 0.9, p, 0.1))
    # ---- spiral galaxy disc above the impact point
    if t <= 335:
        g = min(1.0, t / 100); g = g * g * (3 - 2 * g)
        fade = 1.0 if t <= 295 else max(0.0, (335 - t) / 40)
        if fade > 0 and g > 0.02:
            rmax = 4 + 22 * g
            rot = t * 0.04 + max(0, t - T_IMPACT) * 0.03
            G = (0, 27, 8)
            al = 0.95
            def gp(x, z):
                return W(add(G, (x, z * math.sin(al), z * math.cos(al))))
            for arm in range(3):
                n = N(24 * fade)
                for i in range(n):
                    u = (i + random.random()) / max(1, n)
                    r = 1.5 + (rmax - 1.5) * u ** 0.85
                    a = arm * 2 * math.pi / 3 + 3.6 * u + rot
                    col = GOLD if u < 0.22 else (PINK if u < 0.45 else (PURP if u < 0.7 else BLUE))
                    L.append(dust(col, 1.7 + 0.8 * u, gp(r * math.cos(a), r * math.sin(a)), 0.35 + 1.1 * u))
            for _ in range(N(5 * fade)):
                L.append(dust(WHITE, 2.6, gp(random.gauss(0, .8), random.gauss(0, .8)), 0.3))
            for _ in range(N(2 * fade)):
                L.append(part('end_rod', gp(random.gauss(0, 1), random.gauss(0, 1)), 0.3, 0.0, 1))
            for _ in range(N(9 * fade)):
                r = rmax * math.sqrt(random.random()); a = random.uniform(0, 6.283)
                L.append(dust_ct(PURP, 1.5, BLUE, gp(r * math.cos(a), r * math.sin(a)), 0.8))
    # ---- charging: black/red haki gathers on the fist
    if t < T_IMPACT + 3:
        i = 0.15 + 0.85 * min(1.0, t / 200) ** 1.3
        F0 = (-0.55, 1.25, 0.75)
        for _ in range(1 + int(3 * i * DENSITY)):
            B = add(F0, mul(rnd_dir(-0.6), 1.2 + 2.5 * i))
            L += bolt(F0, B, segs=3, jit=0.25, sz=0.9, spark=False)
        L.append(part('electric_spark', F0, (0.5, 0.5, 0.5), 0.08, 1 + int(5 * i)))
        L.append(dust(RED, 1.5 + i, F0, 0.15, 2))
        L.append(dust(BLACK, 1.8, F0, 0.25, 2))
        for s in (0, 1):
            a = t * 0.5 + s * math.pi
            rad = 1.3 + 0.5 * i
            h = (t * 0.17 + s * 1.2) % 2.6
            L.append(dust(BLACK if s == 0 else RED, 1.3, (rad * math.cos(a), h, rad * math.sin(a)), 0.05))
        for _ in range(N(3 * i)):
            r = random.uniform(0.5, 2.8); a = random.uniform(0, 6.283)
            L.append(dust(RED, 1.0, (r * math.cos(a), 0.05, r * math.sin(a)), 0.05))
        if t % 2 == 0:
            L.append(part('large_smoke', (0, 0.1, 0), (0.8, 0.05, 0.8), 0.01, 1))
    # ---- the fist comes down like a meteor
    if 185 <= t <= 209:
        s = (t - 184) / 25
        p = s ** 1.7
        S = (0, 70, -35)
        H = mul(S, 1 - p)
        back = norm(S)
        for v in FIB20:
            L.append(dust(BLACK, 3, W(add(H, mul(v, 2.3))), 0.15))
        for v in FIB10:
            L.append(dust(RED, 2.6, W(add(H, mul(v, 3.3))), 0.2))
        L.append(part('end_rod', W(H), (1, 1, 1), 0.1, 3))
        for j in range(1, N(10) + 1):
            q = W(add(H, mul(back, j * 1.6)))
            L.append(dust(BLACK, 2.6, q, 0.6))
            if j % 2 == 0:
                L.append(dust(RED, 2.2, q, 0.7))
        L.append(part('electric_spark', W(H), (2, 2, 2), 0.2, 5))
    # ---- IMPACT
    if t == T_IMPACT:
        L += [part('flash', W((0, 4, 0))), part('flash', W((0, 10, 0))), part('flash', W((0, 18, 0))),
              part('sonic_boom', W((0, 3, 0))),
              part('explosion_emitter', W((0, 3, 0)), (7, 3, 7), 0, 10),
              part('block minecraft:dirt', W((0, 1, 0)), (6, 1, 6), 1.2, 150),
              part('block minecraft:stone', W((0, 1, 0)), (6, 1, 6), 1.0, 100),
              part('large_smoke', W((0, 1, 0)), (5, 1, 5), 0.35, 80),
              part('squid_ink', W((0, 2, 0)), (3, 2, 3), 0.5, 60)]
    if t in (T_IMPACT + 1, T_IMPACT + 3):
        L.append(part('explosion_emitter', W((0, 4, 0)), (12, 4, 12), 0, 8))
        L.append(part('flash', W((0, 8, 0))))
    # dome / shockwave
    if T_IMPACT <= t < T_IMPACT + 70:
        k = t - T_IMPACT
        r = 2 + k * 0.95
        keep = int(70 * max(0.15, 1 - k / 70) * DENSITY)
        a0 = random.uniform(0, 6.283)
        for idx, v in enumerate(HEMI90[:keep] if keep < 90 else HEMI90):
            q = W(mul(roty(v, a0), r))
            L.append(dust(BLACK, 2.4, q, 0.5))
            if idx % 3 == 0:
                L.append(dust(RED, 2.0, q, 0.6))
        for _ in range(N(7)):
            B = mul(rnd_dir(0.0), r * 0.98)
            L += bolt(W((0, 1, 0)), W(B), segs=4, jit=0.07 * r + 0.5)
    # ground ring
    if T_IMPACT <= t < T_IMPACT + 65:
        k = t - T_IMPACT
        R = min(60.0, 2 + k * 1.3)
        n = N(70)
        for i in range(n):
            a = i * 2 * math.pi / n + random.uniform(-0.05, 0.05)
            q = W((R * math.cos(a), 0.4, R * math.sin(a)))
            L.append(dust(BLACK, 2.5, q, 0.4))
            if i % 3 == 0:
                L.append(dust(RED, 2.0, q, 0.4))
            if i % 6 == 0:
                L.append(part('block minecraft:dirt', q, (0.4, 0.8, 0.4), 0.3, 4))
    # cyclone column
    if T_IMPACT <= t < T_IMPACT + 90:
        k = t - T_IMPACT
        Hh = min(60.0, k * 2.6)
        heights = 9 if k < 60 else 5
        for hi in range(heights):
            h = Hh * hi / max(1, heights - 1)
            for q in range(3):
                a = t * 0.35 + h * 0.25 + q * 2.094
                rad = 2.5 + h * 0.12
                p = W((rad * math.cos(a), h, rad * math.sin(a)))
                L.append(dust(BLACK if (hi + q) % 2 else RED, 3, p, 0.3))
    # galaxy swirl spreading over the ground
    if T_IMPACT <= t < T_IMPACT + 90:
        k = t - T_IMPACT
        R = min(40.0, k * 0.8 + 2)
        fade = 1.0 if k < 60 else (90 - k) / 30
        n = N(20 * fade)
        for arm in range(3):
            for i in range(n):
                u = (i + random.random()) / max(1, n)
                r = 1 + (R - 1) * u
                a = arm * 2.094 + 3.2 * u + t * 0.08
                L.append(dust_ct(PURP, 1.8, BLUE, W((r * math.cos(a), 0.6 + 0.4 * math.sin(i), r * math.sin(a))), 0.3))
        L.append(dust(WHITE, 3, W((0, 1, 0)), 0.8, 2))
    # aftershock
    if t == T_AFTER:
        L += [part('flash', W((0, 6, 0))), part('sonic_boom', W((0, 3, 0))),
              part('explosion_emitter', W((0, 3, 0)), (6, 2, 6), 0, 6),
              part('block minecraft:dirt', W((0, 1, 0)), (5, 1, 5), 1.0, 80)]
    if T_AFTER <= t < T_AFTER + 30:
        k = t - T_AFTER
        R = 2 + k * 1.5
        n = N(60)
        for i in range(n):
            a = i * 2 * math.pi / n
            q = W((R * math.cos(a), 0.4, R * math.sin(a)))
            L.append(dust(BLACK, 2.2, q, 0.4))
            if i % 3 == 0:
                L.append(dust(RED, 1.8, q, 0.4))
        r = 2 + k * 1.0
        a0 = random.uniform(0, 6.283)
        for idx, v in enumerate(HEMI45):
            if idx % max(1, int(1 / max(DENSITY, 0.1))) == 0:
                L.append(dust(BLACK, 2.2, W(mul(roty(v, a0), r)), 0.5))
        for _ in range(N(5)):
            L += bolt(W((0, 1, 0)), W(mul(rnd_dir(0.0), r)), segs=4, jit=0.07 * r + 0.4)
    # afterglow over the crater
    if T_IMPACT + 70 <= t <= 345:
        L.append(part('large_smoke', W((0, 1, 0)), (3, 1, 3), 0.02, 4))
        L.append(part('block minecraft:dirt', W((0, 18, 0)), (8, 6, 8), 0.0, 3))
        if t % 2 == 0:
            L += bolt(W((0, 0.5, 0)), W(add((0, 0.5, 0), mul(rnd_dir(0.0), random.uniform(3, 7)))), segs=3, jit=0.4, sz=1.2)
    return L

# ---------------------------------------------------------------- HAOSHOKU HAKI
HK_T = 290
HK_PULSES = [(20, 32.0, 16, False), (57, 64.0, 24, True)]   # (tick, max radius, duration, big)

def hk(t):
    L = []
    chest = (0, 1.2, 0)
    if t < 20: a = 0.2 + 0.5 * t / 20
    elif t < 57: a = 0.9
    elif t < 150: a = 1.0 - 0.75 * (t - 57) / 93
    else: a = max(0.0, 0.25 * (1 - (t - 150) / 130))
    # crackling arcs around the body
    for _ in range(N(1 + 7 * a)):
        B = add(chest, mul(rnd_dir(-0.5), random.uniform(2.5, 3 + 5 * a)))
        B = (B[0], max(0.1, B[1]), B[2])
        L += bolt(chest, B, segs=4, jit=0.5, sz=1.2)
    for _ in range(N(5 * a)):
        ang = random.uniform(0, 6.283); r = random.uniform(0.6, 2.2); h = random.uniform(0, 2.8)
        p = (r * math.cos(ang), h, r * math.sin(ang))
        L.append(dust(BLACK, 1.6, p, 0.2))
        if random.random() < 0.5:
            L.append(dust(RED, 1.3, p, 0.2))
    for _ in range(N(6 * a)):
        r = random.uniform(1, 2.5 + 6 * a); ang = random.uniform(0, 6.283)
        L.append(dust(RED, 1.1, (r * math.cos(ang), 0.05, r * math.sin(ang)), 0.1))
    for _ in range(N(2 * a)):
        r = random.uniform(0.5, 3 + 4 * a); ang = random.uniform(0, 6.283)
        L.append(part('large_smoke', (r * math.cos(ang), 0.2, r * math.sin(ang)), (0.3, 0.1, 0.3), 0.0, 1))
    for s in (0, 1):
        ang = t * 0.45 + s * math.pi
        L.append(dust(BLACK if s == 0 else RED, 1.4, (1.2 * math.cos(ang), (t * 0.17 + s * 1.3) % 2.8, 1.2 * math.sin(ang)), 0.05))
    # ripples
    if 20 < t <= 140 and (t % 20) < 12 and not any(t0 <= t < t0 + d for t0, _, d, _ in HK_PULSES):
        r = 1 + (t % 20) * 1.2
        n = N(28)
        for i in range(n):
            ang = i * 2 * math.pi / n
            q = (r * math.cos(ang), 0.3, r * math.sin(ang))
            L.append(dust(BLACK, 1.6, q, 0.2))
            if i % 3 == 0:
                L.append(dust(RED, 1.4, q, 0.2))
    # big pulses (the Haoshoku shockwave)
    for t0, Rmax, dur, big in HK_PULSES:
        if t0 <= t < t0 + dur:
            k = t - t0
            f = (k + 1) / dur
            r = Rmax * f ** 0.75
            if k == 0:
                L += [part('sonic_boom', chest),
                      part('large_smoke', (0, 1, 0), (1, 1, 1), 0.25, 60),
                      part('squid_ink', (0, 1, 0), (1, 1, 1), 0.35, 40)]
            n = N(55)
            for i in range(n):
                ang = i * 2 * math.pi / n + random.uniform(-0.04, 0.04)
                q = (r * math.cos(ang), 1.0, r * math.sin(ang))
                L.append(dust(BLACK, 2.4, q, 0.3))
                if i % 3 == 0:
                    L.append(dust(RED, 2.0, q, 0.3))
            for i in range(N(30)):
                ang = random.uniform(0, 6.283)
                L.append(dust(BLACK, 2.0, (r * math.cos(ang), 0.3, r * math.sin(ang)), 0.3))
            a0 = random.uniform(0, 6.283)
            for idx, v in enumerate(HEMI45):
                q = mul(roty(v, a0), r)
                L.append(dust(BLACK, 2.2, q, 0.4))
                if idx % 4 == 0:
                    L.append(dust(RED, 1.8, q, 0.5))
            for _ in range(N(11)):
                B = mul(rnd_dir(-0.05), r)
                B = (B[0], max(0.2, B[1]), B[2])
                L += bolt(chest, B, segs=5, jit=0.08 * r + 0.3)
            if big and k < 14:
                for _ in range(2):
                    B = (random.uniform(-2, 2), 70, random.uniform(-2, 2))
                    L += bolt((0, 0, 0), B, segs=12, jit=2.4, sz=2.6)
    return L

# ---------------------------------------------------------------- writers
def w(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', newline='\n') as fh:
        fh.write(text)

def build():
    if os.path.exists(OUT):
        shutil.rmtree(OUT)
    base = os.path.join(OUT, 'data', NS, 'functions')
    if not NO_MCMETA:
        w(os.path.join(OUT, 'pack.mcmeta'),
          '{"pack":{"pack_format":15,"description":"One Piece FX: Galaxy Impact + Haoshoku Haki (Minecraft 1.20.1)"}}\n')
    w(os.path.join(OUT, 'data', 'minecraft', 'tags', 'functions', 'load.json'), '{"values":["%s:load"]}\n' % NS)
    w(os.path.join(OUT, 'data', 'minecraft', 'tags', 'functions', 'tick.json'), '{"values":["%s:tick"]}\n' % NS)
    w(os.path.join(base, 'load.mcfunction'), 'scoreboard objectives add opfx_t dummy\n')
    w(os.path.join(base, 'tick.mcfunction'),
      'execute as @e[type=minecraft:marker,tag=opfx_gi] at @s run function opfx:gi/step\n'
      'execute as @e[type=minecraft:marker,tag=opfx_haki] at @s run function opfx:haki/step\n')
    w(os.path.join(base, 'stop.mcfunction'),
      'kill @e[type=minecraft:marker,tag=opfx]\n'
      'stopsound @a * opfx:galaxy_impact\n'
      'stopsound @a * opfx:haki\n')

    def starter(name, tag, sound, vol, comment):
        w(os.path.join(base, name + '.mcfunction'),
          '# %s\n# Run as the player: /function opfx:%s\n'
          '# From a command block: execute as @p at @s run function opfx:%s\n'
          'playsound opfx:%s master @a ~ ~ ~ %s 1 0.5\n'
          'tag @s add opfx_caster\n'
          'summon minecraft:marker ~ ~ ~ {Tags:["opfx","%s","opfx_new"]}\n'
          'execute as @e[type=minecraft:marker,tag=opfx_new,distance=..1] rotated as @e[type=!minecraft:marker,tag=opfx_caster,limit=1] run tp @s ~ ~ ~ ~ 0\n'
          'tag @e[type=minecraft:marker,tag=opfx_new] remove opfx_new\n'
          'tag @s remove opfx_caster\n' % (comment, name, name, sound, vol, tag))

    starter('galaxy_impact', 'opfx_gi', 'galaxy_impact', 6, "Garp's Galaxy Impact")
    starter('haki', 'opfx_haki', 'haki', 8, "Conqueror's (Haoshoku) Haki")

    for key, T, fn in (('gi', GI_T, gi), ('haki', HK_T, hk)):
        step = ['scoreboard players add @s opfx_t 1']
        total = 0
        longest = 0
        for t in range(1, T + 1):
            lines = fn(t)
            total += len(lines)
            longest = max(longest, len(lines))
            w(os.path.join(base, key, 'f', '%d.mcfunction' % t), '\n'.join(lines) + '\n')
            step.append('execute if score @s opfx_t matches %d run function opfx:%s/f/%d' % (t, key, t))
        step.append('execute if score @s opfx_t matches %d.. run kill @s' % (T + 1))
        w(os.path.join(base, key, 'step.mcfunction'), '\n'.join(step) + '\n')
        print('%s: %d frames, %d particle commands, max %d / tick' % (key, T, total, longest))

if __name__ == '__main__':
    build()
