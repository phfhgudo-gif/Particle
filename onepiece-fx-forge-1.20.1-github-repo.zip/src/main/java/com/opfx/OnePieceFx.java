package com.opfx;

import net.minecraftforge.fml.common.Mod;

/**
 * One Piece FX. All the work is done by the data files inside the jar:
 *   /function opfx:galaxy_impact   (Garp's Galaxy Impact)
 *   /function opfx:haki            (Conqueror's Haki)
 *   /function opfx:stop
 */
@Mod(OnePieceFx.MOD_ID)
public class OnePieceFx {
    public static final String MOD_ID = "opfx";

    public OnePieceFx() {
    }
}
